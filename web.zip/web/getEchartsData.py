# -*- coding:utf-8 -*-

import pandas as pd

def getEchartsData(num):
    # read data
    data = pd.read_excel('asset.xlsx')

    # build data
    ip = data['IP'][:num].tolist()
    port = data['端口'][:num].tolist()
    xj = data['协议'][:num].tolist()
    mac = data['Mac'][:num].tolist()
    host = data['Host'][:num].tolist()
    appl = data['应用层'][:num].tolist()
    supl = data['支撑层'][:num].tolist()
    serl = data['服务层'][:num].tolist()
    sysl = data['系统层'][:num].tolist()
    hardl = data['硬件层'][:num].tolist()
    temc = data['终端分类'][:num].tolist()

    # define relation
    relation = ['端口', '协议', 'Mac', 'Host', '应用层', '支撑层', '服务层', '系统层', '硬件层', '终端分类']
    # category = [{'name':'IP'}]
    # for item in relation:
    #     temp = {}
    #     temp['name'] = item
    #     category.append(temp)
    # print(category)

    # build link
    link = []
    for i in range(len(ip)):
        if port[i].strip() != '-':
            link.append({'target':port[i].strip(),'source':ip[i],'name':relation[0],'des':relation[0]})
        if xj[i].strip() != '-':
            link.append({'target':xj[i].strip(),'source':ip[i],'name':relation[1],'des':relation[1]})
        if mac[i].strip() != '-':
            link.append({'target':mac[i].strip(),'source':ip[i],'name':relation[2],'des':relation[2]})
        if host[i].strip() != '-':
            link.append({'target':host[i].strip(),'source':ip[i],'name':relation[3],'des':relation[3]})
        if appl[i].strip() != '-':
            link.append({'target':appl[i].strip(),'source':ip[i],'name':relation[4],'des':relation[4]})
        if supl[i].strip() != '-':
            link.append({'target':supl[i].strip(),'source':ip[i],'name':relation[5],'des':relation[5]})
        if serl[i].strip() != '-':
            link.append({'target':serl[i].strip(),'source':ip[i],'name':relation[6],'des':relation[6]})
        if sysl[i].strip() != '-':
            link.append({'target':sysl[i].strip(),'source':ip[i],'name':relation[7],'des':relation[7]})
        if hardl[i].strip() != '-':
            link.append({'target':hardl[i].strip(),'source':ip[i],'name':relation[8],'des':relation[8]})
        if temc[i].strip() != '-':
            link.append({'target':temc[i].strip(),'source':ip[i],'name':relation[9],'des':relation[9]})

    # set node data
    def setNode(who):
        return list(set(who))
    ip_set = setNode(ip)
    port_set = setNode(port)
    xj_set = setNode(xj)
    mac_set = setNode(mac)
    host_set = setNode(host)
    appl_set = setNode(appl)
    supl_set = setNode(supl)
    serl_set = setNode(serl)
    sysl_set = setNode(sysl)
    hardl_set = setNode(hardl)
    temc_set = setNode(temc)

    # symbolSize = 60

    # store node data, ! watch category set
    def getNode(node, who, category, symbolSize):
        for item in who:
            if item.strip() != '-':
                node.append({'name': item.strip(), 'des': item.strip(), 'symbolSize': symbolSize, 'category': category})
        return node

    node = []
    node = getNode(node, ip_set, 0, 60)
    node = getNode(node, port_set, 1, 40)
    node = getNode(node, xj_set, 2, 40)
    node = getNode(node, mac_set, 3, 40)
    node = getNode(node, host_set, 4, 40)
    node = getNode(node, appl_set, 5, 40)
    node = getNode(node, supl_set, 6, 40)
    node = getNode(node, serl_set, 7, 40)
    node = getNode(node, sysl_set, 8, 40)
    node = getNode(node, hardl_set, 9, 40)
    node = getNode(node, temc_set, 10, 80)

    print(len(link), len(node))

    link_file = open('link'+str(num)+'.txt', 'a', encoding='utf8')
    node_file = open('node'+str(num)+'.txt', 'a', encoding='utf8')
    # category_file = open('category.txt', 'a', encoding='utf8')
    for item in link:
        item = (str(item).replace("'target'", 'target').replace("'source'", 'source').replace("'name'", 'name').replace("'des'", 'des'))
        link_file.write(str(item) + ',' + '\n')
    for item in node:
        item = (str(item).replace("'name'", 'name').replace("'des'", 'des').replace("'symbolSize'", 'symbolSize').replace("'category'", 'category'))
        node_file.write(str(item) + ',' + '\n')
    #category_file.write(str(category))


if __name__ == '__main__':
    getEchartsData(10)